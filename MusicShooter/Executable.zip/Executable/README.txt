Build Notes

-Unity 4.5.3f3

Set up
-No set up needed in unity
-place player and enemy prefabs into a scene 

Main Features
-Top down space shooter

-Level 1
survive by destoying attacking enemies.

-Level 2
Destory enemy spaceships while defending a friendly space station.

-Level 3
Destroy the enemy space stations before too many eneies spawn.

Confirmation that I have pulled a fresh copy from GitHub

Marco Garcia
5/12/2015